import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Play, Clock, CheckCircle, Link2 } from "lucide-react";
import { Sequence, Video, Course } from "@/types/course";

interface SequenceCardProps {
  sequence: Sequence;
  course: Course;
  onPlayVideo: (course: Course, video: Video, sequenceId: string) => void;
  onNavigateToSequence?: (sequenceId: string) => void;
}

export const SequenceCard = ({ 
  sequence, 
  course, 
  onPlayVideo, 
  onNavigateToSequence 
}: SequenceCardProps) => {
  const navigate = useNavigate();
  const completedVideos = sequence.videos.filter(v => v.completed).length;
  const progress = sequence.videos.length > 0 ? (completedVideos / sequence.videos.length) * 100 : 0;

  const handlePlaySequence = () => {
    const nextVideo = sequence.videos.find(v => !v.completed) || sequence.videos[0];
    if (nextVideo) {
      // Navigate to the new video player page
      navigate(`/course/${course.id}/video?sequence=${sequence.id}&video=${nextVideo.id}`);
    }
  };

  return (
    <Card className="group relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-500 bg-gradient-to-br from-card to-secondary/10">
      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-500"></div>
      
      <CardHeader className="relative pb-4">
        <div className="flex items-start justify-between">
          <div className="space-y-3 flex-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-gradient-primary"></div>
                <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 font-semibold">
                  {sequence.videos.length} Videos
                </Badge>
              </div>
              {sequence.links && sequence.links.length > 0 && (
                <Link2 className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
            <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
              {sequence.title}
            </CardTitle>
            {sequence.description && (
              <p className="text-sm text-muted-foreground">{sequence.description}</p>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative space-y-6">
        {/* Enhanced Progress Section */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-foreground">Progress</span>
            <span className="text-lg font-bold text-primary">{Math.round(progress)}%</span>
          </div>
          <div className="relative">
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div 
                className="h-3 rounded-full bg-gradient-primary transition-all duration-700 ease-out shadow-sm" 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground flex items-center justify-between">
            <span>{completedVideos} completed</span>
            <span>{sequence.videos.length - completedVideos} remaining</span>
          </p>
        </div>

        {/* Video Preview Section */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-foreground flex items-center">
            <Clock className="w-4 h-4 mr-2 text-primary" />
            Videos
          </h4>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {sequence.videos.slice(0, 3).map((video, index) => (
              <div 
                key={video.id} 
                className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-lg cursor-pointer transition-all duration-200 group/video" 
                onClick={() => onPlayVideo(course, video, sequence.id)}
              >
                <div className="flex items-center space-x-3 flex-1">
                  <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center group-hover/video:bg-primary/20 transition-colors text-xs">
                    {index + 1}
                  </div>
                  <span className="text-sm font-medium truncate text-foreground group-hover/video:text-primary transition-colors">
                    {video.title}
                  </span>
                </div>
                {video.completed && (
                  <CheckCircle className="w-4 h-4 text-accent flex-shrink-0" />
                )}
              </div>
            ))}
            {sequence.videos.length > 3 && (
              <div className="text-xs text-muted-foreground px-2 py-1 bg-muted/30 rounded-md">
                +{sequence.videos.length - 3} more videos
              </div>
            )}
          </div>
        </div>

        {/* Sequence Links */}
        {sequence.links && sequence.links.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-foreground flex items-center">
              <Link2 className="w-4 h-4 mr-2 text-primary" />
              Links
            </h4>
            <div className="flex flex-wrap gap-2">
              {sequence.links.map((link) => (
                <Button
                  key={link.id}
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigateToSequence?.(link.targetSequenceId)}
                  className="text-xs"
                >
                  {link.title}
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>

      <div className="p-6 pt-0">
        <Button 
          className="w-full bg-gradient-primary hover:opacity-90 text-white font-semibold py-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 group-hover:shadow-xl" 
          onClick={handlePlaySequence}
        >
          <Play className="w-5 h-5 mr-2" />
          {completedVideos < sequence.videos.length ? 'Continue Sequence' : 'Review Sequence'}
        </Button>
      </div>
    </Card>
  );
};