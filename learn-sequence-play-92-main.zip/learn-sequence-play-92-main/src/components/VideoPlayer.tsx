import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, CheckCircle, Circle, SkipForward, SkipBack, FileText, Download } from "lucide-react";
import { Course, Video, Sequence } from "@/types/course";

interface VideoPlayerProps {
  course: Course;
  currentVideo: Video;
  selectedSequence?: Sequence | null;
  onBack: () => void;
  onVideoComplete: (videoId: string) => void;
  onVideoChange: (video: Video) => void;
}

export const VideoPlayer = ({ 
  course, 
  currentVideo, 
  selectedSequence,
  onBack, 
  onVideoComplete, 
  onVideoChange 
}: VideoPlayerProps) => {
  const [isCompleted, setIsCompleted] = useState(currentVideo.completed || false);
  
  // Get videos from selected sequence or all course videos
  const videoList = selectedSequence ? selectedSequence.videos : 
    course.sequences?.flatMap(seq => seq.videos) || [];
  
  const currentIndex = videoList.findIndex(v => v.id === currentVideo.id);
  const nextVideo = currentIndex < videoList.length - 1 ? videoList[currentIndex + 1] : null;
  const prevVideo = currentIndex > 0 ? videoList[currentIndex - 1] : null;

  useEffect(() => {
    setIsCompleted(currentVideo.completed || false);
  }, [currentVideo]);

  const handleMarkComplete = () => {
    setIsCompleted(!isCompleted);
    onVideoComplete(currentVideo.id);
  };

  const getYouTubeEmbedUrl = (youtubeId: string) => {
    return `https://www.youtube.com/embed/${youtubeId}?rel=0&modestbranding=1`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      {/* Header */}
      <div className="bg-card border-b p-4">
        <div className="flex items-center gap-4 max-w-7xl mx-auto">
          <Button variant="ghost" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-bold">{selectedSequence?.title || course.title}</h1>
            <p className="text-sm text-muted-foreground">{course.subject}</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Video Player Section */}
          <div className="xl:col-span-3 space-y-6">
            {/* Video Player */}
            <Card className="overflow-hidden border-0 shadow-xl">
              <div className="aspect-video bg-black relative">
                <iframe
                  src={getYouTubeEmbedUrl(currentVideo.youtubeId)}
                  title={currentVideo.title}
                  className="w-full h-full"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </Card>

            {/* Video Info and Actions */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="space-y-2 flex-1">
                    <h2 className="text-2xl font-bold text-foreground">{currentVideo.title}</h2>
                    {currentVideo.duration && (
                      <p className="text-muted-foreground">Duration: {currentVideo.duration}</p>
                    )}
                  </div>
                  <Button
                    onClick={handleMarkComplete}
                    variant={isCompleted ? "default" : "outline"}
                    className={`px-6 py-2 font-semibold ${isCompleted ? "bg-accent hover:bg-accent/80" : "border-accent text-accent hover:bg-accent/10"}`}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Mark Complete
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4 mr-2" />
                        Mark Complete
                      </>
                    )}
                  </Button>
                </div>

                {/* Navigation */}
                <div className="flex gap-3">
                  {prevVideo && (
                    <Button 
                      variant="outline" 
                      onClick={() => onVideoChange(prevVideo)}
                      className="flex items-center gap-2"
                    >
                      <SkipBack className="w-4 h-4" />
                      Previous
                    </Button>
                  )}
                  {nextVideo && (
                    <Button 
                      onClick={() => onVideoChange(nextVideo)}
                      className="flex items-center gap-2 bg-gradient-primary hover:opacity-90 text-white"
                    >
                      Next
                      <SkipForward className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Notes and Resources Tabs */}
            <Card className="border-0 shadow-lg">
              <Tabs defaultValue="notes" className="w-full">
                <CardHeader className="pb-2">
                  <TabsList className="grid w-full grid-cols-2 bg-muted/50">
                    <TabsTrigger value="notes" className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Notes
                    </TabsTrigger>
                    <TabsTrigger value="resources" className="flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Resources (PDF)
                    </TabsTrigger>
                  </TabsList>
                </CardHeader>
                <CardContent>
                  <TabsContent value="notes" className="space-y-4">
                    <div className="min-h-[200px] p-4 bg-muted/30 rounded-lg border-2 border-dashed border-muted-foreground/20">
                      <h3 className="font-semibold text-foreground mb-3">Video Notes</h3>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <p>• Key concepts covered in this video</p>
                        <p>• Important formulas and definitions</p>
                        <p>• Practice problems discussed</p>
                        <p>• Tips and tricks for problem-solving</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="resources" className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-red-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Lecture Notes - {currentVideo.title}</h4>
                            <p className="text-sm text-muted-foreground">PDF • 2.5 MB</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="flex items-center gap-2">
                          <Download className="w-4 h-4" />
                          Download
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Practice Problems</h4>
                            <p className="text-sm text-muted-foreground">PDF • 1.8 MB</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="flex items-center gap-2">
                          <Download className="w-4 h-4" />
                          Download
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Solution Manual</h4>
                            <p className="text-sm text-muted-foreground">PDF • 3.2 MB</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="flex items-center gap-2">
                          <Download className="w-4 h-4" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </CardContent>
              </Tabs>
            </Card>
          </div>

          {/* Progress Sidebar */}
          <div className="xl:col-span-1">
            <Card className="border-0 shadow-lg bg-accent/5 sticky top-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-bold text-foreground">
                  {selectedSequence ? `${selectedSequence.title} Progress` : 'Course Progress'}
                </CardTitle>
                <CardDescription className="text-sm">
                  {videoList.filter(v => v.completed).length} of {videoList.length} videos completed
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 max-h-[600px] overflow-y-auto">
                {videoList.map((video, index) => (
                  <div
                    key={video.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 ${
                      video.id === currentVideo.id
                        ? "bg-primary/20 border-primary shadow-sm"
                        : video.completed
                        ? "bg-accent/20 border-accent/30"
                        : "bg-card hover:bg-muted/50 border-border"
                    }`}
                    onClick={() => onVideoChange(video)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold ${
                        video.completed 
                          ? "bg-accent text-white" 
                          : video.id === currentVideo.id
                          ? "bg-primary text-white"
                          : "bg-muted text-muted-foreground"
                      }`}>
                        {video.completed ? "✓" : index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className={`font-medium text-sm truncate ${
                          video.id === currentVideo.id ? "text-primary" : "text-foreground"
                        }`}>
                          {video.title}
                        </h4>
                        {video.duration && (
                          <p className="text-xs text-muted-foreground">{video.duration}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};