import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, Clock, CheckCircle } from "lucide-react";

interface Video {
  id: string;
  title: string;
  youtubeId: string;
  duration?: string;
  completed?: boolean;
}

interface Course {
  id: string;
  title: string;
  subject: string;
  videos: Video[];
}

interface CourseCardProps {
  course: Course;
  onPlayVideo: (course: Course, video: Video) => void;
}

export const CourseCard = ({ course, onPlayVideo }: CourseCardProps) => {
  const completedVideos = course.videos.filter(v => v.completed).length;
  const progress = course.videos.length > 0 ? (completedVideos / course.videos.length) * 100 : 0;

  return (
    <Card className="group relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-500 bg-gradient-to-br from-card to-secondary/10">
      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-500"></div>
      
      <CardHeader className="relative pb-4">
        <div className="flex items-start justify-between">
          <div className="space-y-3 flex-1">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-gradient-primary"></div>
              <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                {course.subject}
              </span>
            </div>
            <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
              {course.title}
            </CardTitle>
          </div>
          <div className="flex flex-col items-end space-y-2">
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 font-semibold">
              {course.videos.length} Videos
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative space-y-6">
        {/* Enhanced Progress Section */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-foreground">Learning Progress</span>
            <span className="text-lg font-bold text-primary">{Math.round(progress)}%</span>
          </div>
          <div className="relative">
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div 
                className="h-3 rounded-full bg-gradient-primary transition-all duration-700 ease-out shadow-sm" 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground flex items-center justify-between">
            <span>{completedVideos} completed</span>
            <span>{course.videos.length - completedVideos} remaining</span>
          </p>
        </div>

        {/* Video Preview Section */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-foreground flex items-center">
            <Clock className="w-4 h-4 mr-2 text-primary" />
            Recent Content
          </h4>
          <div className="space-y-2">
            {course.videos.slice(0, 2).map((video, index) => (
              <div 
                key={video.id} 
                className="flex items-center justify-between p-3 hover:bg-muted/50 rounded-lg cursor-pointer transition-all duration-200 group/video" 
                onClick={() => onPlayVideo(course, video)}
              >
                <div className="flex items-center space-x-3 flex-1">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center group-hover/video:bg-primary/20 transition-colors">
                    <Play className="w-4 h-4 text-primary" />
                  </div>
                  <span className="text-sm font-medium truncate text-foreground group-hover/video:text-primary transition-colors">
                    {video.title}
                  </span>
                </div>
                {video.completed && (
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                )}
              </div>
            ))}
            {course.videos.length > 2 && (
              <div className="text-xs text-muted-foreground px-3 py-1 bg-muted/30 rounded-md">
                +{course.videos.length - 2} more videos available
              </div>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="relative pt-6">
        <Button 
          className="w-full bg-gradient-primary hover:opacity-90 text-white font-semibold py-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 group-hover:shadow-xl" 
          onClick={() => {
            const nextVideo = course.videos.find(v => !v.completed) || course.videos[0];
            onPlayVideo(course, nextVideo);
          }}
        >
          <Play className="w-5 h-5 mr-2" />
          {completedVideos < course.videos.length ? 'Continue Learning' : 'Review Course'}
        </Button>
      </CardFooter>
    </Card>
  );
};