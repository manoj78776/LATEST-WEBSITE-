import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { SequenceCard } from "./SequenceCard";
import { VideoPlayer } from "./VideoPlayer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Play, TrendingUp, Clock, ArrowLeft } from "lucide-react";
import { Course, Video, Sequence } from "@/types/course";

// Helper function to migrate old course structure to new structure
const migrateCourseStructure = (courses: Course[]): Course[] => {
  return courses.map(course => {
    // If course has old videos structure but no sequences
    if (course.videos && course.videos.length > 0 && (!course.sequences || course.sequences.length === 0)) {
      return {
        ...course,
        sequences: [{
          id: `${course.id}-main`,
          title: "Main Content",
          videos: course.videos,
          description: "All course videos"
        }],
        videos: undefined // Remove old structure
      };
    }
    return course;
  });
};

// Default sample data
const defaultCourses: Course[] = [
  {
    id: "1",
    title: "My Course",
    subject: "Programming",
    sequences: [
      {
        id: "1-welcome",
        title: "Welcome Message",
        videos: [
          {
            id: "1-1-1",
            title: "Course Introduction",
            youtubeId: "dQw4w9WgXcQ",
            duration: "5:00"
          },
          {
            id: "1-1-2", 
            title: "What You'll Learn",
            youtubeId: "dQw4w9WgXcQ",
            duration: "3:30"
          }
        ]
      },
      {
        id: "1-basics",
        title: "Programming Basics",
        videos: [
          {
            id: "1-2-1",
            title: "Variables and Data Types", 
            youtubeId: "dQw4w9WgXcQ",
            duration: "15:20"
          }
        ],
        links: [
          {
            id: "link-1",
            title: "Next: Advanced Topics",
            targetSequenceId: "1-advanced",
            type: "next"
          }
        ]
      },
      {
        id: "1-advanced", 
        title: "Advanced Concepts",
        videos: [
          {
            id: "1-3-1",
            title: "Functions and Scope",
            youtubeId: "dQw4w9WgXcQ", 
            duration: "20:45"
          }
        ]
      }
    ]
  }
];

export const StudyDashboard = () => {
  const navigate = useNavigate();
  const [courses, setCourses] = useState<Course[]>([]);
  const [currentView, setCurrentView] = useState<'dashboard' | 'course' | 'player'>('dashboard');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedSequence, setSelectedSequence] = useState<Sequence | null>(null);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);

  // Load courses from localStorage on component mount
  useEffect(() => {
    const savedCourses = localStorage.getItem('studyCourses');
    if (savedCourses) {
      const loadedCourses = JSON.parse(savedCourses);
      // Migrate old structure to new structure
      const migratedCourses = migrateCourseStructure(loadedCourses);
      setCourses(migratedCourses);
      // Save migrated structure back to localStorage
      localStorage.setItem('studyCourses', JSON.stringify(migratedCourses));
    } else {
      // If no saved courses, use default data
      setCourses(defaultCourses);
      localStorage.setItem('studyCourses', JSON.stringify(defaultCourses));
    }
  }, []);

  const totalVideos = courses.reduce((acc, course) => 
    acc + (course.sequences?.reduce((seqAcc, seq) => seqAcc + seq.videos.length, 0) || 0), 0
  );
  const completedVideos = courses.reduce((acc, course) => 
    acc + (course.sequences?.reduce((seqAcc, seq) => 
      seqAcc + seq.videos.filter(v => v.completed).length, 0
    ) || 0), 0
  );
  const overallProgress = totalVideos > 0 ? (completedVideos / totalVideos) * 100 : 0;

  const handleCourseSelect = (course: Course) => {
    setSelectedCourse(course);
    setCurrentView('course');
  };

  const handlePlayVideo = (course: Course, video: Video, sequenceId?: string) => {
    setSelectedCourse(course);
    setCurrentVideo(video);
    if (sequenceId) {
      const sequence = course.sequences?.find(s => s.id === sequenceId);
      setSelectedSequence(sequence || null);
    }
    setCurrentView('player');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedCourse(null);
    setSelectedSequence(null);
    setCurrentVideo(null);
  };

  const handleBackToCourse = () => {
    setCurrentView('course');
    setSelectedSequence(null);
    setCurrentVideo(null);
  };

  const handleNavigateToSequence = (sequenceId: string) => {
    if (selectedCourse) {
      const sequence = selectedCourse.sequences?.find(s => s.id === sequenceId);
      if (sequence && sequence.videos.length > 0) {
        const firstVideo = sequence.videos[0];
        handlePlayVideo(selectedCourse, firstVideo, sequenceId);
      }
    }
  };

  const handleVideoComplete = (videoId: string) => {
    // In a real app, you'd update this in a database
    // For now, we'll just update the local state
    console.log('Video completed:', videoId);
  };

  const handleVideoChange = (video: Video) => {
    setCurrentVideo(video);
  };

  if (currentView === 'player' && selectedCourse && currentVideo) {
    return (
      <VideoPlayer
        course={selectedCourse}
        currentVideo={currentVideo}
        selectedSequence={selectedSequence}
        onBack={selectedSequence ? handleBackToCourse : handleBackToDashboard}
        onVideoComplete={handleVideoComplete}
        onVideoChange={handleVideoChange}
      />
    );
  }

  if (currentView === 'course' && selectedCourse) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
        <div className="container mx-auto px-4 py-8 space-y-8">
          {/* Course Header */}
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={handleBackToDashboard} className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Courses
            </Button>
            <div className="flex-1">
              <h1 className="text-4xl font-bold bg-gradient-hero bg-clip-text text-transparent">
                {selectedCourse.title}
              </h1>
              <p className="text-lg text-muted-foreground">{selectedCourse.subject}</p>
            </div>
          </div>

          {/* Course Sequences */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">Course Sequences</h2>
            {selectedCourse.sequences && selectedCourse.sequences.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {selectedCourse.sequences.map((sequence) => (
                  <SequenceCard
                    key={sequence.id}
                    sequence={sequence}
                    course={selectedCourse}
                    onPlayVideo={handlePlayVideo}
                    onNavigateToSequence={handleNavigateToSequence}
                  />
                ))}
              </div>
            ) : (
              <Card className="text-center py-16 border-0 shadow-lg bg-gradient-to-br from-card to-secondary/20">
                <CardContent className="space-y-6">
                  <div className="mx-auto w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center">
                    <BookOpen className="w-10 h-10 text-white" />
                  </div>
                  <div className="space-y-3">
                    <h3 className="text-2xl font-bold text-foreground">No Sequences Yet</h3>
                    <p className="text-muted-foreground max-w-md mx-auto leading-relaxed">
                      This course doesn't have any sequences yet. Add sequences through the admin panel.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header - PW Style */}
        <div className="text-center space-y-6 py-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              Learning Portal
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Master new skills with our comprehensive video course collection. Track your progress and achieve your learning goals.
            </p>
          </div>
          <div className="flex justify-center">
            <div className="bg-gradient-primary p-1 rounded-full">
              <div className="bg-background px-6 py-2 rounded-full">
                <span className="text-sm font-semibold text-primary">🎯 Your Learning Journey Starts Here</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Overview - PW Style */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-primary opacity-10"></div>
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-base font-semibold text-foreground">Total Courses</CardTitle>
              <div className="p-2 bg-primary/10 rounded-lg">
                <BookOpen className="h-5 w-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-3xl font-bold text-primary mb-1">{courses.length}</div>
              <p className="text-sm text-muted-foreground font-medium">
                Subjects available
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-accent opacity-10"></div>
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-base font-semibold text-foreground">Progress</CardTitle>
              <div className="p-2 bg-accent/10 rounded-lg">
                <TrendingUp className="h-5 w-5 text-accent" />
              </div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-3xl font-bold text-accent mb-1">
                {Math.round(overallProgress)}%
              </div>
              <p className="text-sm text-muted-foreground font-medium">
                {completedVideos} of {totalVideos} completed
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-progress/10 to-progress/5"></div>
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-base font-semibold text-foreground">Total Videos</CardTitle>
              <div className="p-2 bg-progress/10 rounded-lg">
                <Play className="h-5 w-5 text-progress" />
              </div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-3xl font-bold text-progress mb-1">{totalVideos}</div>
              <p className="text-sm text-muted-foreground font-medium">
                Learning materials
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Courses Section - PW Style */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold text-foreground">Your Learning Path</h2>
              <p className="text-muted-foreground">Choose a subject and start your journey</p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline"
                onClick={() => navigate('/math')}
                className="border-accent/20 text-accent hover:bg-accent/5 hover:border-accent/40"
              >
                NDA Mathematics
              </Button>
              <Button 
                variant="outline"
                onClick={() => navigate('/admin')}
                className="border-primary/20 text-primary hover:bg-primary/5 hover:border-primary/40"
              >
                Manage Courses
              </Button>
            </div>
          </div>
          
          {courses.length === 0 ? (
            <Card className="text-center py-16 border-0 shadow-lg bg-gradient-to-br from-card to-secondary/20">
              <CardContent className="space-y-6">
                <div className="mx-auto w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center">
                  <BookOpen className="w-10 h-10 text-white" />
                </div>
                <div className="space-y-3">
                  <h3 className="text-2xl font-bold text-foreground">Start Your Learning Journey</h3>
                  <p className="text-muted-foreground max-w-md mx-auto leading-relaxed">
                    Create your first course and begin exploring new topics. Add YouTube videos and organize your learning materials.
                  </p>
                </div>
                <Button 
                  className="bg-gradient-primary hover:opacity-90 text-white px-8 py-3 text-lg rounded-full shadow-lg"
                  onClick={() => navigate('/admin')}
                >
                  Create First Course
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {courses.map((course) => (
                <Card 
                  key={course.id}
                  className="group relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-500 bg-gradient-to-br from-card to-secondary/10 cursor-pointer"
                  onClick={() => handleCourseSelect(course)}
                >
                  <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-500"></div>
                  
                  <CardHeader className="relative pb-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-3 flex-1">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-gradient-primary"></div>
                          <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                            {course.subject}
                          </span>
                        </div>
                        <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                          {course.title}
                        </CardTitle>
                      </div>
                      <div className="flex flex-col items-end space-y-2">
                        <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 font-semibold">
                          {course.sequences?.length || 0} Sequences
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="relative space-y-4">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        {course.sequences?.reduce((acc, seq) => acc + seq.videos.length, 0) || 0} total videos
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {course.sequences?.reduce((acc, seq) => acc + seq.videos.filter(v => v.completed).length, 0) || 0} completed
                      </p>
                    </div>
                  </CardContent>

                  <div className="p-6 pt-0">
                    <Button 
                      className="w-full bg-gradient-primary hover:opacity-90 text-white font-semibold py-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 group-hover:shadow-xl" 
                    >
                      <BookOpen className="w-5 h-5 mr-2" />
                      View Sequences
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};