import { Course } from "@/types/course";

// Helper function to extract YouTube video ID from URL
const extractYouTubeId = (url: string): string => {
  const match = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : "dQw4w9WgXcQ"; // fallback to Rick Roll if invalid URL
};

// Mathematics Course Data - NDA Shaurya 1.0 2026
export const mathCourse: Course = {
  id: "nda-math-2026",
  title: "NDA Shaurya 1.0 2026 Mathematics",
  subject: "Mathematics",
  sequences: [
    {
      id: "quadratic-equations",
      title: "Quadratic Equations",
      description: "Comprehensive coverage of quadratic equations, their properties, and solution methods",
      videos: [
        {
          id: "quad-01",
          title: "Quadratic Equations - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/KU8EHO6YMZA"),
          duration: "45:00"
        },
        {
          id: "quad-02", 
          title: "Quadratic Equations - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/OTOWNFwaSEA"),
          duration: "50:00"
        },
        {
          id: "quad-03",
          title: "Quadratic Equations - Part 03", 
          youtubeId: extractYouTubeId("https://youtu.be/v5KztgAkbZ0"),
          duration: "42:00"
        },
        {
          id: "quad-04",
          title: "Quadratic Equations - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/q0tpXkSp9WU"),
          duration: "38:00"
        }
      ]
    },
    {
      id: "complex-numbers",
      title: "Complex Numbers",
      description: "Understanding complex numbers, their operations, and applications",
      videos: [
        {
          id: "complex-01",
          title: "Complex Numbers - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/m2V6TP8bGSo"),
          duration: "55:00"
        },
        {
          id: "complex-02",
          title: "Complex Numbers - Part 02", 
          youtubeId: extractYouTubeId("https://youtu.be/q4MWx1DuY1Y"),
          duration: "48:00"
        },
        {
          id: "complex-03",
          title: "Complex Numbers - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/avpulUgReYE"),
          duration: "52:00"
        },
        {
          id: "complex-04",
          title: "Complex Numbers - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/YwXf_zIQYzc"),
          duration: "46:00"
        },
        {
          id: "complex-05",
          title: "Complex Numbers - Part 05",
          youtubeId: extractYouTubeId("https://youtu.be/_LcUF6bUn9w"),
          duration: "44:00"
        },
        {
          id: "complex-06",
          title: "Complex Numbers - Part 06",
          youtubeId: extractYouTubeId("https://youtu.be/MRUylmS44Xk"),
          duration: "40:00"
        }
      ],
      links: [
        {
          id: "complex-to-log",
          title: "Next: Logarithms",
          targetSequenceId: "logarithms",
          type: "next"
        }
      ]
    },
    {
      id: "logarithms",
      title: "Logarithms", 
      description: "Logarithmic functions, properties, and problem-solving techniques",
      videos: [
        {
          id: "log-rec01",
          title: "Logarithms - Revision 01",
          youtubeId: extractYouTubeId("https://youtu.be/mLGlAgcOM_Y"),
          duration: "35:00"
        },
        {
          id: "log-rec02",
          title: "Logarithms - Revision 02", 
          youtubeId: extractYouTubeId("https://youtu.be/GsF969SjwPM"),
          duration: "38:00"
        }
      ]
    },
    {
      id: "binomial-theorem",
      title: "Binomial Theorem",
      description: "Binomial expansions, coefficients, and applications",
      videos: [
        {
          id: "binomial-01",
          title: "Binomial Theorem - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/SnsR4WZWKmc"),
          duration: "48:00"
        },
        {
          id: "binomial-02",
          title: "Binomial Theorem - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/dDrDFZImGkw"),
          duration: "45:00"
        },
        {
          id: "binomial-03",
          title: "Binomial Theorem - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/X4GUGh2rmes"),
          duration: "42:00"
        },
        {
          id: "binomial-04",
          title: "Binomial Theorem - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/Lp50U8H8jjE"),
          duration: "40:00"
        }
      ]
    },
    {
      id: "permutations-combinations",
      title: "Permutations & Combinations (PNC)",
      description: "Counting principles, permutations, combinations, and probability basics",
      videos: [
        {
          id: "pnc-01",
          title: "Permutations & Combinations - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/Z1DGc5EXA90"),
          duration: "52:00"
        },
        {
          id: "pnc-02",
          title: "Permutations & Combinations - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/r20gON--FmU"),
          duration: "50:00"
        },
        {
          id: "pnc-03",
          title: "Permutations & Combinations - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/vgvOpcWKzXA"),
          duration: "48:00"
        },
        {
          id: "pnc-04",
          title: "Permutations & Combinations - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/E7EyEXbdlyE"),
          duration: "46:00"
        }
      ]
    },
    {
      id: "probability",
      title: "Probability",
      description: "Probability theory, conditional probability, and applications",
      videos: [
        {
          id: "prob-01",
          title: "Probability - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/j7r2CKKwRUQ"),
          duration: "55:00"
        },
        {
          id: "prob-02",
          title: "Probability - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/XNxyDzZZI60"),
          duration: "50:00"
        },
        {
          id: "prob-03",
          title: "Probability - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/bSV_L_n22kI"),
          duration: "48:00"
        },
        {
          id: "prob-04",
          title: "Probability - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/9TxU0DoIb58"),
          duration: "45:00"
        },
        {
          id: "prob-05",
          title: "Probability - Part 05",
          youtubeId: extractYouTubeId("https://youtu.be/Z8OG9xTjL5g"),
          duration: "42:00"
        },
        {
          id: "prob-06",
          title: "Probability - Part 06",
          youtubeId: extractYouTubeId("https://youtu.be/OgMuiKVYw3c"),
          duration: "40:00"
        }
      ]
    },
    {
      id: "sequences-series",
      title: "Sequences & Series",
      description: "Arithmetic and geometric progressions, infinite series",
      videos: [
        {
          id: "seq-rec01",
          title: "Sequences & Series - Revision 01",
          youtubeId: extractYouTubeId("https://youtu.be/Uz8DjuWSs48"),
          duration: "45:00"
        },
        {
          id: "seq-rec02",
          title: "Sequences & Series - Revision 02",
          youtubeId: extractYouTubeId("https://youtu.be/IVTYe97r9pE"),
          duration: "48:00"
        },
        {
          id: "seq-rec03",
          title: "Sequences & Series - Revision 03",
          youtubeId: extractYouTubeId("https://youtu.be/JYvplLk4bbU"),
          duration: "42:00"
        },
        {
          id: "seq-rec04",
          title: "Sequences & Series - Revision 04",
          youtubeId: extractYouTubeId("https://youtu.be/UeCWUTeAbE0"),
          duration: "40:00"
        },
        {
          id: "seq-rec05",
          title: "Sequences & Series - Revision 05",
          youtubeId: extractYouTubeId("https://youtu.be/GEuH-eM2-4A"),
          duration: "38:00"
        }
      ]
    },
    {
      id: "set-theory",
      title: "Set Theory",
      description: "Set operations, Venn diagrams, and set relations",
      videos: [
        {
          id: "set-rec01",
          title: "Set Theory - Revision 01",
          youtubeId: extractYouTubeId("https://youtu.be/ebg2VXkJVKI"),
          duration: "35:00"
        },
        {
          id: "set-rec02",
          title: "Set Theory - Revision 02",
          youtubeId: extractYouTubeId("https://youtu.be/cT56Ek4JVew"),
          duration: "38:00"
        },
        {
          id: "set-rec03",
          title: "Set Theory - Revision 03",
          youtubeId: extractYouTubeId("https://youtu.be/DnIihSHT6iU"),
          duration: "32:00"
        }
      ]
    },
    {
      id: "matrices-determinants",
      title: "Matrices & Determinants",
      description: "Matrix operations, determinants, and solving linear systems",
      videos: [
        {
          id: "matrix-01",
          title: "Matrices & Determinants - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/xd4BfD_If7k"),
          duration: "50:00"
        },
        {
          id: "matrix-02",
          title: "Matrices & Determinants - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/Ga7oITsPxB8"),
          duration: "55:00"
        },
        {
          id: "matrix-03",
          title: "Matrices & Determinants - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/DoiIE5_Dcmc"),
          duration: "48:00"
        },
        {
          id: "matrix-04",
          title: "Matrices & Determinants - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/MLW48MaIj9U"),
          duration: "45:00"
        }
      ]
    },
    {
      id: "trigonometry",
      title: "Trigonometry",
      description: "Trigonometric functions, identities, and equations",
      videos: [
        {
          id: "trig-01",
          title: "Trigonometry - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/8WjfWpZZs_0"),
          duration: "52:00"
        },
        {
          id: "trig-02",
          title: "Trigonometry - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/rCIJJux65W4"),
          duration: "48:00"
        },
        {
          id: "trig-03",
          title: "Trigonometry - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/qsbG-fLHDig"),
          duration: "50:00"
        },
        {
          id: "trig-04",
          title: "Trigonometry - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/u4eAD90AAJI"),
          duration: "45:00"
        },
        {
          id: "trig-05",
          title: "Trigonometry - Part 05",
          youtubeId: extractYouTubeId("https://youtu.be/UzcoIsLf7LI"),
          duration: "42:00"
        }
      ]
    },
    {
      id: "statistics",
      title: "Statistics",
      description: "Statistical measures, data analysis, and probability distributions",
      videos: [
        {
          id: "stats-rec01",
          title: "Statistics - Revision 01",
          youtubeId: extractYouTubeId("https://youtu.be/u02LCDbZLDU"),
          duration: "40:00"
        },
        {
          id: "stats-rec02",
          title: "Statistics - Revision 02",
          youtubeId: extractYouTubeId("https://youtu.be/zYsKMpayLIg"),
          duration: "42:00"
        },
        {
          id: "stats-rec03",
          title: "Statistics - Revision 03",
          youtubeId: extractYouTubeId("https://youtu.be/cXfLr7aNp04"),
          duration: "38:00"
        },
        {
          id: "stats-rec04",
          title: "Statistics - Revision 04",
          youtubeId: extractYouTubeId("https://youtu.be/8Lzxqv7p4Ec"),
          duration: "35:00"
        }
      ]
    },
    {
      id: "relations-functions",
      title: "Relations & Functions",
      description: "Mathematical relations, function types, and their properties",
      videos: [
        {
          id: "rel-func-01",
          title: "Relations & Functions - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/AH_KoVgGk6A"),
          duration: "50:00"
        },
        {
          id: "rel-func-02",
          title: "Relations & Functions - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/qKiHfHBSSjA"),
          duration: "48:00"
        },
        {
          id: "rel-func-03",
          title: "Relations & Functions - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/cA20D5b37kA"),
          duration: "45:00"
        },
        {
          id: "rel-func-04",
          title: "Relations & Functions - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/Eoejsp_2deY"),
          duration: "42:00"
        }
      ]
    },
    {
      id: "differentiation",
      title: "Differentiation",
      description: "Derivative concepts, rules, and applications",
      videos: [
        {
          id: "diff-01",
          title: "Differentiation - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/Kp_sCBPB5fE"),
          duration: "55:00"
        },
        {
          id: "diff-02",
          title: "Differentiation - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/qUGTrGgrFrQ"),
          duration: "52:00"
        }
      ],
      links: [
        {
          id: "diff-to-limits",
          title: "Prerequisite: Limits",
          targetSequenceId: "limits",
          type: "prerequisite"
        }
      ]
    },
    {
      id: "limits",
      title: "Limits",
      description: "Limit concepts, evaluation techniques, and continuity",
      videos: [
        {
          id: "limits-01",
          title: "Limits - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/K2rs6jkfXcU"),
          duration: "48:00"
        },
        {
          id: "limits-02",
          title: "Limits - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/1yL0ZTZn_jM"),
          duration: "45:00"
        }
      ]
    },
    {
      id: "continuity",
      title: "Continuity",
      description: "Function continuity, discontinuities, and applications",
      videos: [
        {
          id: "continuity-01",
          title: "Continuity - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/ZfTTwg1mluo"),
          duration: "42:00"
        }
      ]
    },
    {
      id: "differentiability",
      title: "Differentiability",
      description: "Function differentiability and related concepts",
      videos: [
        {
          id: "differentiability-01",
          title: "Differentiability - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/QSGfJis0AdE"),
          duration: "40:00"
        }
      ]
    },
    {
      id: "aod",
      title: "Application of Derivatives (AOD)",
      description: "Practical applications of derivatives in problem solving",
      videos: [
        {
          id: "aod-01",
          title: "Application of Derivatives - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/tRzk7U0z9Kg"),
          duration: "50:00"
        },
        {
          id: "aod-02",
          title: "Application of Derivatives - Part 02", 
          youtubeId: extractYouTubeId("https://youtu.be/CSAEygQ_zIs"),
          duration: "48:00"
        },
        {
          id: "aod-03",
          title: "Application of Derivatives - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/lacAW5omeo4"),
          duration: "45:00"
        }
      ]
    },
    {
      id: "indefinite-integrals",
      title: "Indefinite Integrals",
      description: "Integration techniques and indefinite integrals",
      videos: [
        {
          id: "indef-01",
          title: "Indefinite Integrals - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/d95bUwo6RBk"),
          duration: "52:00"
        },
        {
          id: "indef-02",
          title: "Indefinite Integrals - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/5aH2-s2ufaI"),
          duration: "50:00"
        },
        {
          id: "indef-03",
          title: "Indefinite Integrals - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/0mKHwL1qN58"),
          duration: "48:00"
        },
        {
          id: "indef-04",
          title: "Indefinite Integrals - Part 04",
          youtubeId: extractYouTubeId("https://youtu.be/dBsjmFDeCzA"),
          duration: "45:00"
        }
      ]
    },
    {
      id: "definite-integrals",
      title: "Definite Integrals",
      description: "Definite integration and applications",
      videos: [
        {
          id: "def-01",
          title: "Definite Integrals - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/eNcaci9DbBs"),
          duration: "50:00"
        },
        {
          id: "def-02",
          title: "Definite Integrals - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/w8iw417YXJw"),
          duration: "48:00"
        },
        {
          id: "def-03",
          title: "Definite Integrals - Part 03",
          youtubeId: extractYouTubeId("https://youtu.be/7q71OxH0O34"),
          duration: "45:00"
        }
      ]
    },
    {
      id: "area-under-curve",
      title: "Area under Curve (AOI)",
      description: "Applications of integration in finding areas",
      videos: [
        {
          id: "aoi-01",
          title: "Area under Curve - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/5yAnmxygHnw"),
          duration: "45:00"
        },
        {
          id: "aoi-02",
          title: "Area under Curve - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/8COzHDwbEe0"),
          duration: "42:00"
        }
      ]
    },
    {
      id: "differential-equations",
      title: "Differential Equations",
      description: "Solving differential equations and their applications",
      videos: [
        {
          id: "diff-eq-01",
          title: "Differential Equations - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/aFBUChNuq4g"),
          duration: "50:00"
        },
        {
          id: "diff-eq-02",
          title: "Differential Equations - Part 02",
          youtubeId: extractYouTubeId("https://youtu.be/tgjyqJrpiB0"),
          duration: "48:00"
        }
      ]
    },
    {
      id: "binary-numbers",
      title: "Binary Numbers", 
      description: "Number systems and binary operations",
      videos: [
        {
          id: "binary-01",
          title: "Binary Numbers - Part 01",
          youtubeId: extractYouTubeId("https://youtu.be/dlUmk2Nn288"),
          duration: "35:00"
        }
      ]
    }
  ]
};