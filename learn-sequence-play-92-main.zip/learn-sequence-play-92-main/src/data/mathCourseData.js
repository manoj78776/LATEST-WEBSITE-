import React from "react";

// All NDA Shaurya 1.0 2026 Mathematics Lectures topics
const mathCourseData = [
  // Quadratic Equations
  { chapter: "Quadratic Equations", parts: [
    { part: "01", video: "https://youtu.be/KU8EHO6YMZA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/da05f9d0-5faf-4d52-ac35-367f7e15cb7e.pdf", dpp: null },
    { part: "02", video: "https://youtu.be/OTOWNFwaSEA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/3424e87e-22a5-4c3e-848c-9dbd73e50cd2.pdf", dpp: ["https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/fa20ba33-f000-4434-89ae-7c8625c0f5b2.pdf", "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/3ea0d877-0369-4d45-b73b-e1c40e3275f4.pdf"] },
    { part: "03", video: "https://youtu.be/v5KztgAkbZ0", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/207731f3-1e44-4a13-b047-fca66c22d0ba.pdf", dpp: null },
    { part: "04", video: "https://youtu.be/q0tpXkSp9WU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/357c2c02-f68a-4c4c-97bc-9359a8b23581.pdf", dpp: null },
  ]},
  // Complex Numbers
  { chapter: "Complex Numbers", parts: [
    { part: "01", video: "https://youtu.be/m2V6TP8bGSo", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f30fa821-5611-4c48-b435-a6741fc1fb8e.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/49abd797-4244-43dc-9b40-61f6ed62d2ca.pdf" },
    { part: "02", video: "https://youtu.be/q4MWx1DuY1Y", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/541f1c4a-c7a8-41d9-a057-edb3666b4fa5.pdf", dpp: null },
    { part: "03", video: "https://youtu.be/avpulUgReYE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/eec5cf65-911f-4691-9baa-c27aea8f0643.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f121c902-43d6-40a0-8316-2a2d70b74e05.pdf" },
    { part: "04", video: "https://youtu.be/YwXf_zIQYzc", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/e04498f7-d0d3-4d64-a581-25dd2f99d411.pdf", dpp: null },
    { part: "05", video: "https://youtu.be/_LcUF6bUn9w", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/684df97e-9d7f-466a-b73a-14a8901b3b06.pdf", dpp: null },
    { part: "06", video: "https://youtu.be/MRUylmS44Xk", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/e00f0a73-1db4-418d-a134-4844c42d4702.pdf", dpp: null },
  ]},
  // Logarithms
  { chapter: "Logarithms", parts: [
    { part: "Rec01", video: "https://youtu.be/mLGlAgcOM_Y", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ebf65a93-a51a-4615-875c-a873fd81392a.pdf", dpp: null },
    { part: "Rec02", video: "https://youtu.be/GsF969SjwPM", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/858cc497-33f4-4f22-92e5-c62235f78f3e.pdf", dpp: null },
  ]},
  // Binomial Theorem
  { chapter: "Binomial Theorem", parts: [
    { part: "01", video: "https://youtu.be/SnsR4WZWKmc", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/9ca20a83-e264-4fad-9b8f-5bcc60d5c636.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/95333f2e-c1d1-4ddd-a5a6-a8b2a8e07b5b.pdf" },
    { part: "02", video: "https://youtu.be/dDrDFZImGkw", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/daa379b0-4355-4953-a06b-94d72e5b9795.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/965ba205-f21a-4cf5-9f46-d53d9f4e3948.pdf" },
    { part: "03", video: "https://youtu.be/X4GUGh2rmes", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/d82b41ab-4acd-4fc6-9ee1-87687df8a435.pdf", dpp: null },
    { part: "04", video: "https://youtu.be/Lp50U8H8jjE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/c3dab7c1-7fb5-4fb2-a28a-a3f8e94336e6.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/9514a7dd-d803-48c4-bdd2-1e5ee272e52a.pdf" },
  ]},
  // Permutations & Combinations (PNC)
  { chapter: "Permutations & Combinations (PNC)", parts: [
    { part: "01", video: "https://youtu.be/Z1DGc5EXA90", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/5343cd17-3472-4f96-aa2a-6dc3d9db16dd.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/935e3fb7-ac06-4b92-bd27-ce373bfb8f35.pdf" },
    { part: "02", video: "https://youtu.be/r20gON--FmU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/fd3320e0-2a18-403d-8d6e-1bdee64f03da.pdf", dpp: null },
    { part: "03", video: "https://youtu.be/vgvOpcWKzXA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/274bbb7a-0565-4f07-8faf-37da6d1e4ce8.pdf", dpp: null },
    { part: "04", video: "https://youtu.be/E7EyEXbdlyE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/46015f9e-0ca4-42c0-a272-5ea44c0e26c6.pdf", dpp: null },
  ]},
  // Probability
  { chapter: "Probability", parts: [
    { part: "01", video: "https://youtu.be/j7r2CKKwRUQ", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/12a6b125-6d02-458c-a420-5a16dfb15b3f.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/c40a26fa-7386-486b-81a7-666d05dc32c5.pdf" },
    { part: "02", video: "https://youtu.be/XNxyDzZZI60", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/38640550-2250-4bbd-92da-266ee70cf931.pdf", dpp: null },
    { part: "03", video: "https://youtu.be/bSV_L_n22kI", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/060a86bb-9778-42ab-b49b-e9c0e2fd396c.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ab20dcb0-a219-4063-aeef-390c5ccbff4e.pdf" },
    { part: "04", video: "https://youtu.be/9TxU0DoIb58", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/51b9ab7d-e7ed-46d6-9146-4733793d5d1b.pdf", dpp: null },
    { part: "05", video: "https://youtu.be/Z8OG9xTjL5g", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/7f1eab26-cea9-46e1-9e52-91f65f7261d8.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/a8bceadd-0288-485c-aedf-42139645a49a.pdf" },
    { part: "06", video: "https://youtu.be/OgMuiKVYw3c", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/30acfaae-ebe0-4508-a29f-90d47a2fc4e0.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ce8dcb2a-0df0-42bb-a942-8603e5394e37.pdf" },
  ]},
  // Sequences & Series
  { chapter: "Sequences & Series", parts: [
    { part: "Rec01", video: "https://youtu.be/Uz8DjuWSs48", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/68daeeb1-3622-4cf3-8e31-e80b354eb863.pdf", dpp: null },
    { part: "Rec02", video: "https://youtu.be/IVTYe97r9pE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/1cdb8534-c51d-427d-ab34-1badf6d1c6c8.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/2a92d82f-802d-4484-a619-9493cd86bc0b.pdf" },
    { part: "Rec03", video: "https://youtu.be/JYvplLk4bbU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/bbb822a1-7b70-43a2-b432-777e1b78f025.pdf", dpp: null },
    { part: "Rec04", video: "https://youtu.be/UeCWUTeAbE0", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/8e93aaa1-5b6d-4a6a-b4e8-02d41784e9aa.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/0efd7efe-684a-4408-be9a-3aafaf282ab6.pdf" },
    { part: "Rec05", video: "https://youtu.be/GEuH-eM2-4A", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/9bccf859-0432-4e41-b63e-477ada43976c.pdf", dpp: null },
  ]},
    // Set Theory
    { chapter: "Set Theory", parts: [
      { part: "Rec01", video: "https://youtu.be/ebg2VXkJVKI", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/969242e1-3a30-4e6a-90d8-b41f8fee54fe.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/4ec26a2a-ca8c-4b86-a626-9587002be38d.pdf" },
      { part: "Rec02", video: "https://youtu.be/cT56Ek4JVew", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/e1da90db-ca77-4dc2-a5a4-c33d8fb647e1.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/4f6388a7-14c1-4fcd-9453-72d86ce37549.pdf" },
      { part: "Rec03", video: "https://youtu.be/DnIihSHT6iU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/8baddea8-b976-4047-9470-4fc622e3d44b.pdf", dpp: null },
    ]},
    // Matrices & Determinants
    { chapter: "Matrices & Determinants", parts: [
      { part: "01", video: "https://youtu.be/xd4BfD_If7k", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f5a8204e-539a-4fb8-9d2b-ee5ff9410baa.pdf", dpp: null },
      { part: "02", video: "https://youtu.be/Ga7oITsPxB8", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/a3c7467e-55a2-4ab2-aac0-23bd21a2634b.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/99d0316f-3963-4830-9c34-fee78a228b2a.pdf" },
      { part: "03", video: "https://youtu.be/DoiIE5_Dcmc", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/637b5341-e85b-4709-bdaa-dab33b54a662.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/17358d3c-3223-4131-8f8d-c4d5022e92b8.pdf" },
      { part: "04", video: "https://youtu.be/MLW48MaIj9U", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/8ea6fc88-7328-49c1-b59f-057e35b07073.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/0e3514aa-5906-4943-ac60-64ed3c1a13bf.pdf" },
    ]},
    // Trigonometry
    { chapter: "Trigonometry", parts: [
      { part: "01", video: "https://youtu.be/8WjfWpZZs_0", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/a9df3ea1-dc5d-4851-9acf-30499327281a.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/fcde23fb-0f4a-474e-b129-ddd111a85603.pdf" },
      { part: "02", video: "https://youtu.be/rCIJJux65W4", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/87367375-3c8a-41d4-958e-4967587f3dcc.pdf", dpp: null },
      { part: "03", video: "https://youtu.be/qsbG-fLHDig", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/aaac4cb8-a2d3-4d55-a02f-e7d35827f46e.pdf", dpp: null },
      { part: "04", video: "https://youtu.be/u4eAD90AAJI", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f208ef19-8480-4a24-a21c-ecc40b63c724.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/3c022add-a340-418f-8355-ea5b60098c79.pdf" },
      { part: "05", video: "https://youtu.be/UzcoIsLf7LI", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/924deabb-1ef7-4835-b98a-f1973e6beabe.pdf", dpp: null },
    ]},
    // Statistics
    { chapter: "Statistics", parts: [
      { part: "Rec01", video: "https://youtu.be/u02LCDbZLDU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/6ce46601-7518-470c-a23d-d67d802270a0.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/bbedc00c-278c-4fc6-8e22-4132ce8442e3.pdf" },
      { part: "Rec02", video: "https://youtu.be/zYsKMpayLIg", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/68e4cfe6-ee0d-4482-9918-5e23ccda71e1.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/33ab0475-d1ce-4b01-a9a1-04c66c4b7ad0.pdf" },
      { part: "Rec03", video: "https://youtu.be/cXfLr7aNp04", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/e102ba9e-955e-4bd7-bd68-7d8f20948223.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/532a60ec-4e5a-413f-82d9-97bb09dd4d37.pdf" },
      { part: "Rec04", video: "https://youtu.be/8Lzxqv7p4Ec", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/e102ba9e-955e-4bd7-bd68-7d8f20948223.pdf", dpp: "https://teamshivaay977.vercel.app/practice/684d319887aea8fb79c3ca6c" },
    ]},
    // Relation & Function
    { chapter: "Relation & Function", parts: [
      { part: "01", video: "https://youtu.be/AH_KoVgGk6A", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/1edd3eb2-41b5-4554-a9b5-b02c1f76d487.pdf", dpp: ["https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/31c55eaa-98d0-48f1-964b-0193fd7ea935.pdf", "https://teamshivaay977.vercel.app/practice/684d319887aea8fb79c3ca6c"] },
      { part: "02", video: "https://youtu.be/qKiHfHBSSjA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/81ebcef0-b323-49bf-bece-bb380d7327d7.pdf", dpp: ["https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/7def6aa0-7793-4acd-b0ee-25c1fb677e0e.pdf", "https://teamshivaay977.vercel.app/practice/684d319887aea8fb79c3ca6c"] },
      { part: "03", video: "https://youtu.be/cA20D5b37kA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/d9af9775-60b8-4590-956e-13baa8aaf769.pdf", dpp: ["https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/cb655cf7-bd79-4039-a4a2-5aa39f22e4f9.pdf", "https://teamshivaay977.vercel.app/practice/684d319887aea8fb79c3ca6c"] },
      { part: "04", video: "https://youtu.be/Eoejsp_2deY", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ddcd74cc-2fef-4816-bac6-b8d153d0c8b8.pdf", dpp: ["https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/c49332d7-5488-481f-95c2-885ac70093c4.pdf", "https://teamshivaay977.vercel.app/practice/684d319887aea8fb79c3ca6c"] },
    ]},
    // Differentiation
    { chapter: "Differentiation", parts: [
      { part: "01", video: "https://youtu.be/Kp_sCBPB5fE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/9e605066-adea-470a-b324-68279c413ccf.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/20b1ff88-0652-4aad-8371-77b89eaddedf.pdf" },
      { part: "02", video: "https://youtu.be/qUGTrGgrFrQ", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/fbb99219-7656-482d-a984-92b4f51e4634.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/bcf79535-4fa0-41e1-bc95-543ca102b514.pdf" },
    ]},
    // Limits
    { chapter: "Limits", parts: [
      { part: "01", video: "https://youtu.be/K2rs6jkfXcU", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/b213e2de-5a2a-4869-aa4b-ae0788a926d2.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/a722e318-b2e5-4c45-89d3-5787302d373e.pdf" },
      { part: "02", video: "https://youtu.be/1yL0ZTZn_jM", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/67687b3f-68bc-4fc7-a17c-0323ed40dc6d.pdf", dpp: null },
    ]},
    // Continuity
    { chapter: "Continuity", parts: [
      { part: "01", video: "https://youtu.be/ZfTTwg1mluo", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f0512ac3-b411-47bf-a320-a261066c17ac.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/3f1d3770-3415-4da2-921c-59a0251588c7.pdf" },
    ]},
    // Differentiability
    { chapter: "Differentiability", parts: [
      { part: "01", video: "https://youtu.be/QSGfJis0AdE", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/cfbe6441-18e7-4563-859e-50da3d07d235.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/2cb004fc-2b5d-4de8-a6b4-11fe409bb9f3.pdf" },
    ]},
    // Application of Derivatives (AOD)
    { chapter: "Application of Derivatives (AOD)", parts: [
      { part: "01", video: "https://youtu.be/tRzk7U0z9Kg", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/a9950556-a051-4b2e-867d-49488cedf27e.pdf", dpp: null },
      { part: "02", video: "https://youtu.be/CSAEygQ_zIs", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/81bba161-a871-415d-9781-b169ef734e1f.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ea98731c-6764-4d8a-95e6-74965e84d5bf.pdf" },
      { part: "03", video: "https://youtu.be/lacAW5omeo4", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ef86e1d5-625b-4d09-9175-401b8671e793.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/298bef05-3612-4d21-9e85-9046cb5fc990.pdf" },
    ]},
    // Indefinite Integrals
    { chapter: "Indefinite Integrals", parts: [
      { part: "01", video: "https://youtu.be/d95bUwo6RBk", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/355a3613-2e16-43d4-9953-6a42ee245f32.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/10f5a5ac-6442-426e-97d7-9d9f98e84046.pdf" },
      { part: "02", video: "https://youtu.be/5aH2-s2ufaI", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/d9034e6c-0b2b-4636-8d9c-50efd4b32d53.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ca1c61a3-a415-4907-9979-f768ffd1fdc5.pdf" },
      { part: "03", video: "https://youtu.be/0mKHwL1qN58", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/de259a04-ffb3-402e-bcda-1ee5a391c64a.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/95cffb2a-ffca-411f-9e4a-884f7646cdb4.pdf" },
      { part: "04", video: "https://youtu.be/dBsjmFDeCzA", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/883285c2-ddb6-4062-8f93-4c52eee02eba.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/6000f0fb-cf01-495e-8443-ecb7996f8c0d.pdf" },
    ]},
    // Definite Integrals
    { chapter: "Definite Integrals", parts: [
      { part: "01", video: "https://youtu.be/eNcaci9DbBs", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/2d2e37b2-47a6-411d-be79-2db017de4c6d.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/86706d78-4ddd-4bab-9d35-976a0b33eb3e.pdf" },
      { part: "02", video: "https://youtu.be/w8iw417YXJw", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/aeb4bf32-7fb9-4151-a438-3ff4f53404c1.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/b9397697-bc41-4384-a985-5511a93e4de3.pdf" },
      { part: "03", video: "https://youtu.be/7q71OxH0O34", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/f38da2be-c942-4d79-b6c5-51ac5f2d4048.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/08eb8f0e-1cdd-497a-8469-b5b7c93e03ba.pdf" },
    ]},
    // Area under Curve (AOI)
    { chapter: "Area under Curve (AOI)", parts: [
      { part: "01", video: "https://youtu.be/5yAnmxygHnw", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/a318160c-1285-44ca-8c99-c2c7ceb5dfcf.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/dab72a62-a0ba-411c-92fe-89a0fb41de4d.pdf" },
      { part: "02", video: "https://youtu.be/8COzHDwbEe0", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/0a07ad11-5da6-4647-80e0-1d22e64ca9fb.pdf", dpp: null },
    ]},
    // Differential Equations
    { chapter: "Differential Equations", parts: [
      { part: "01", video: "https://youtu.be/aFBUChNuq4g", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/63ef67f3-db70-4c21-86ae-008242595082.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/5ec54c4b-7726-4416-a07f-37d1a5788c19.pdf" },
      { part: "02", video: "https://youtu.be/tgjyqJrpiB0", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/47162a6e-2359-4fb0-a7ee-a2f6e255daa2.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/9b0953b1-17ae-40c4-b44e-59e7d2bbd2c7.pdf" },
    ]},
    // Binary Numbers
    { chapter: "Binary Numbers", parts: [
      { part: "01", video: "https://youtu.be/dlUmk2Nn288", notes: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/3827349e-7e4d-4206-94ff-7ca1ffe07803.pdf", dpp: "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ac123559-9a4b-41c4-a5a2-af4f3b026634.pdf" },
    ]},
];

const MathCoursePage = () => (
  <div className="p-6 max-w-4xl mx-auto">
  <h1 className="text-3xl font-bold mb-6">NDA Shaurya 1.0 2026 Math Lectures</h1>
    {mathCourseData.map((chapter) => (
      <div key={chapter.chapter} className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">{chapter.chapter}</h2>
        <table className="w-full border mb-4">
          <thead>
            <tr className="bg-gray-100">
              <th className="border px-2 py-1">Part</th>
              <th className="border px-2 py-1">Video</th>
              <th className="border px-2 py-1">Notes</th>
              <th className="border px-2 py-1">DPP/Practice</th>
            </tr>
          </thead>
          <tbody>
            {chapter.parts.map((part, idx) => (
              <tr key={idx}>
                <td className="border px-2 py-1">{part.part}</td>
                <td className="border px-2 py-1">
                  <a href={part.video} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Video</a>
                </td>
                <td className="border px-2 py-1">
                  <a href={part.notes} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Notes</a>
                </td>
                <td className="border px-2 py-1">
                  {part.dpp ? (
                    Array.isArray(part.dpp) ? (
                      part.dpp.map((dppLink, i) => (
                        <div key={i}>
                          <a href={dppLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">DPP {i + 1}</a>
                        </div>
                      ))
                    ) : (
                      <a href={part.dpp} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">DPP</a>
                    )
                  ) : (
                    "-"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    ))}
  </div>
);

export default MathCoursePage;
