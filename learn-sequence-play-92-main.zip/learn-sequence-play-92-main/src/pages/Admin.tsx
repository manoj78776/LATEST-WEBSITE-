import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Plus, Trash2, Edit3, Save, X, Link2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Course, Video, Sequence, SequenceLink } from "@/types/course";

// Helper function to migrate old course structure to new structure
const migrateCourseStructure = (courses: Course[]): Course[] => {
  return courses.map(course => {
    // If course has old videos structure but no sequences
    if (course.videos && course.videos.length > 0 && (!course.sequences || course.sequences.length === 0)) {
      return {
        ...course,
        sequences: [{
          id: `${course.id}-main`,
          title: "Main Content",
          videos: course.videos,
          description: "All course videos"
        }],
        videos: undefined // Remove old structure
      };
    }
    return course;
  });
};

// Helper function to extract YouTube ID from URL
const extractYouTubeId = (url: string): string => {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/ // Direct ID
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return url; // Return as-is if no pattern matches
};

const Admin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [courses, setCourses] = useState<Course[]>([]);

  // Load courses from localStorage on component mount
  useEffect(() => {
    const savedCourses = localStorage.getItem('studyCourses');
    if (savedCourses) {
      const loadedCourses = JSON.parse(savedCourses);
      // Migrate old structure to new structure
      const migratedCourses = migrateCourseStructure(loadedCourses);
      setCourses(migratedCourses);
      // Save migrated structure back to localStorage
      localStorage.setItem('studyCourses', JSON.stringify(migratedCourses));
    } else {
      // Initialize with default course if no data exists
      const defaultCourses: Course[] = [
        {
          id: "1",
          title: "My Course",
          subject: "Programming",
          sequences: [
            {
              id: "1-welcome",
              title: "Welcome Message",
              videos: [
                {
                  id: "1-1-1",
                  title: "Course Introduction",
                  youtubeId: "dQw4w9WgXcQ",
                  duration: "5:00"
                }
              ]
            }
          ]
        }
      ];
      setCourses(defaultCourses);
      localStorage.setItem('studyCourses', JSON.stringify(defaultCourses));
    }
  }, []);

  // Save courses to localStorage whenever courses change
  useEffect(() => {
    if (courses.length > 0) {
      localStorage.setItem('studyCourses', JSON.stringify(courses));
    }
  }, [courses]);

  const [editingCourse, setEditingCourse] = useState<string | null>(null);
  const [newCourse, setNewCourse] = useState({
    title: "",
    subject: ""
  });

  const [newSequence, setNewSequence] = useState({
    courseId: "",
    title: "",
    description: ""
  });

  const [newVideo, setNewVideo] = useState({
    courseId: "",
    sequenceId: "", 
    title: "",
    youtubeUrls: "",
    duration: ""
  });

  const [newLink, setNewLink] = useState({
    courseId: "",
    sequenceId: "",
    title: "",
    targetSequenceId: "",
    type: "next" as "next" | "prerequisite" | "related"
  });

  const handleAddCourse = () => {
    if (!newCourse.title.trim()) {
      toast({
        title: "Error",
        description: "Course title is required",
        variant: "destructive"
      });
      return;
    }

    const course: Course = {
      id: Date.now().toString(),
      title: newCourse.title,
      subject: newCourse.subject || "General",
      sequences: []
    };

    setCourses([...courses, course]);
    setNewCourse({ title: "", subject: "" });
    
    toast({
      title: "Success",
      description: "Course added successfully!"
    });
  };

  const handleAddSequence = () => {
    if (!newSequence.title.trim() || !newSequence.courseId) {
      toast({
        title: "Error", 
        description: "Course selection and sequence title are required",
        variant: "destructive"
      });
      return;
    }

    const sequence: Sequence = {
      id: `${newSequence.courseId}-${Date.now()}`,
      title: newSequence.title,
      description: newSequence.description,
      videos: [],
      links: []
    };

    setCourses(courses.map(course => 
      course.id === newSequence.courseId 
        ? { ...course, sequences: [...(course.sequences || []), sequence] }
        : course
    ));

    setNewSequence({ courseId: "", title: "", description: "" });
    
    toast({
      title: "Success",
      description: "Sequence added successfully!"
    });
  };

  const handleAddVideo = () => {
    if (!newVideo.youtubeUrls.trim() || !newVideo.courseId || !newVideo.sequenceId) {
      toast({
        title: "Error",
        description: "Course, sequence selection and YouTube URLs are required",
        variant: "destructive"
      });
      return;
    }

    // Split URLs by newlines and filter out empty lines
    const urls = newVideo.youtubeUrls.split('\n').filter(url => url.trim());
    
    if (urls.length === 0) {
      toast({
        title: "Error",
        description: "Please provide at least one YouTube URL",
        variant: "destructive"
      });
      return;
    }

    const newVideos: Video[] = urls.map((url, index) => {
      const youtubeId = extractYouTubeId(url.trim());
      return {
        id: `${newVideo.sequenceId}-${Date.now()}-${index}`,
        title: newVideo.title.trim() || `Video ${index + 1}`,
        youtubeId: youtubeId,
        duration: newVideo.duration || "0:00"
      };
    });

    setCourses(courses.map(course => 
      course.id === newVideo.courseId 
        ? { 
            ...course, 
            sequences: course.sequences?.map(seq => 
              seq.id === newVideo.sequenceId
                ? { ...seq, videos: [...seq.videos, ...newVideos] }
                : seq
            ) || []
          }
        : course
    ));

    setNewVideo({ courseId: "", sequenceId: "", title: "", youtubeUrls: "", duration: "" });
    
    toast({
      title: "Success",
      description: `${newVideos.length} video(s) added successfully!`
    });
  };

  const handleAddLink = () => {
    if (!newLink.title.trim() || !newLink.courseId || !newLink.sequenceId || !newLink.targetSequenceId) {
      toast({
        title: "Error",
        description: "All fields are required for adding a link",
        variant: "destructive"
      });
      return;
    }

    const link: SequenceLink = {
      id: `${newLink.sequenceId}-link-${Date.now()}`,
      title: newLink.title,
      targetSequenceId: newLink.targetSequenceId,
      type: newLink.type
    };

    setCourses(courses.map(course => 
      course.id === newLink.courseId 
        ? { 
            ...course, 
            sequences: course.sequences?.map(seq => 
              seq.id === newLink.sequenceId
                ? { ...seq, links: [...(seq.links || []), link] }
                : seq
            ) || []
          }
        : course
    ));

    setNewLink({ courseId: "", sequenceId: "", title: "", targetSequenceId: "", type: "next" });
    
    toast({
      title: "Success",
      description: "Link added successfully!"
    });
  };

  const handleDeleteCourse = (courseId: string) => {
    setCourses(courses.filter(c => c.id !== courseId));
    toast({
      title: "Success",
      description: "Course deleted successfully!"
    });
  };

  const handleDeleteSequence = (courseId: string, sequenceId: string) => {
    setCourses(courses.map(course =>
      course.id === courseId
        ? { ...course, sequences: course.sequences?.filter(s => s.id !== sequenceId) || [] }
        : course
    ));
    toast({
      title: "Success", 
      description: "Sequence deleted successfully!"
    });
  };

  const handleDeleteVideo = (courseId: string, sequenceId: string, videoId: string) => {
    setCourses(courses.map(course =>
      course.id === courseId
        ? { 
            ...course, 
            sequences: course.sequences?.map(seq =>
              seq.id === sequenceId
                ? { ...seq, videos: seq.videos.filter(v => v.id !== videoId) }
                : seq
            ) || []
          }
        : course
    ));
    toast({
      title: "Success",
      description: "Video deleted successfully!"
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate("/")} className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Course Admin Panel
            </h1>
            <p className="text-muted-foreground">
              Manage your YouTube courses and videos
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add New Course */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Add New Course
              </CardTitle>
              <CardDescription>
                Create a new course for your study collection
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="course-title">Course Title *</Label>
                <Input
                  id="course-title"
                  placeholder="e.g., React Fundamentals"
                  value={newCourse.title}
                  onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course-subject">Subject Name *</Label>
                <Input
                  id="course-subject"
                  placeholder="e.g., Programming, Mathematics, Science"
                  value={newCourse.subject}
                  onChange={(e) => setNewCourse({ ...newCourse, subject: e.target.value })}
                />
              </div>
              <Button onClick={handleAddCourse} className="w-full bg-gradient-primary hover:opacity-90">
                <Plus className="w-4 h-4 mr-2" />
                Add Course
              </Button>
            </CardContent>
          </Card>

          {/* Add New Sequence */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Add Sequence to Course
              </CardTitle>
              <CardDescription>
                Create organized sequences like "Welcome", "Basics", etc.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="sequence-course">Select Course *</Label>
                <select
                  id="sequence-course"
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  value={newSequence.courseId}
                  onChange={(e) => setNewSequence({ ...newSequence, courseId: e.target.value })}
                >
                  <option value="">Choose a course...</option>
                  {courses.map(course => (
                    <option key={course.id} value={course.id}>{course.title}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="sequence-title">Sequence Title *</Label>
                <Input
                  id="sequence-title"
                  placeholder="e.g., Welcome Message, Know Your Educators"
                  value={newSequence.title}
                  onChange={(e) => setNewSequence({ ...newSequence, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sequence-description">Description (optional)</Label>
                <Input
                  id="sequence-description"
                  placeholder="Brief description of this sequence"
                  value={newSequence.description}
                  onChange={(e) => setNewSequence({ ...newSequence, description: e.target.value })}
                />
              </div>
              <Button onClick={handleAddSequence} className="w-full bg-gradient-accent hover:opacity-90">
                <Plus className="w-4 h-4 mr-2" />
                Add Sequence
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add New Video */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Add Video to Sequence
              </CardTitle>
              <CardDescription>
                Add YouTube videos to a specific sequence
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="video-course">Select Course *</Label>
                <select
                  id="video-course"
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  value={newVideo.courseId}
                  onChange={(e) => {
                    setNewVideo({ ...newVideo, courseId: e.target.value, sequenceId: "" });
                  }}
                >
                  <option value="">Choose a course...</option>
                  {courses.map(course => (
                    <option key={course.id} value={course.id}>{course.title}</option>
                  ))}
                </select>
              </div>
              
              {newVideo.courseId && (
                <div className="space-y-2">
                  <Label htmlFor="video-sequence">Select Sequence *</Label>
                  <select
                    id="video-sequence"
                    className="w-full px-3 py-2 border border-input bg-background rounded-md"
                    value={newVideo.sequenceId}
                    onChange={(e) => setNewVideo({ ...newVideo, sequenceId: e.target.value })}
                  >
                    <option value="">Choose a sequence...</option>
                    {courses.find(c => c.id === newVideo.courseId)?.sequences?.map(sequence => (
                      <option key={sequence.id} value={sequence.id}>{sequence.title}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="video-title">Default Video Title (optional)</Label>
                <Input
                  id="video-title"
                  placeholder="Leave empty to use 'Video 1', 'Video 2', etc."
                  value={newVideo.title}
                  onChange={(e) => setNewVideo({ ...newVideo, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="video-urls">YouTube URLs *</Label>
                <Textarea
                  id="video-urls"
                  placeholder="Paste multiple YouTube URLs, one per line:&#10;https://www.youtube.com/watch?v=abc123&#10;https://www.youtube.com/watch?v=def456&#10;https://youtu.be/ghi789"
                  value={newVideo.youtubeUrls}
                  onChange={(e) => setNewVideo({ ...newVideo, youtubeUrls: e.target.value })}
                  rows={4}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="video-duration">Duration</Label>
                <Input
                  id="video-duration"
                  placeholder="e.g., 15:30"
                  value={newVideo.duration}
                  onChange={(e) => setNewVideo({ ...newVideo, duration: e.target.value })}
                />
              </div>
              <Button onClick={handleAddVideo} className="w-full bg-gradient-primary hover:opacity-90">
                <Plus className="w-4 h-4 mr-2" />
                Add Video
              </Button>
            </CardContent>
          </Card>

          {/* Add Sequence Link */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link2 className="w-5 h-5" />
                Add Sequence Link
              </CardTitle>
              <CardDescription>
                Create links between sequences for navigation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="link-course">Select Course *</Label>
                <select
                  id="link-course"
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  value={newLink.courseId}
                  onChange={(e) => {
                    setNewLink({ ...newLink, courseId: e.target.value, sequenceId: "", targetSequenceId: "" });
                  }}
                >
                  <option value="">Choose a course...</option>
                  {courses.map(course => (
                    <option key={course.id} value={course.id}>{course.title}</option>
                  ))}
                </select>
              </div>
              
              {newLink.courseId && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="link-sequence">From Sequence *</Label>
                    <select
                      id="link-sequence"
                      className="w-full px-3 py-2 border border-input bg-background rounded-md"
                      value={newLink.sequenceId}
                      onChange={(e) => setNewLink({ ...newLink, sequenceId: e.target.value })}
                    >
                      <option value="">Choose a sequence...</option>
                      {courses.find(c => c.id === newLink.courseId)?.sequences?.map(sequence => (
                        <option key={sequence.id} value={sequence.id}>{sequence.title}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="link-target">To Sequence *</Label>
                    <select
                      id="link-target"
                      className="w-full px-3 py-2 border border-input bg-background rounded-md"
                      value={newLink.targetSequenceId}
                      onChange={(e) => setNewLink({ ...newLink, targetSequenceId: e.target.value })}
                    >
                      <option value="">Choose target sequence...</option>
                      {courses.find(c => c.id === newLink.courseId)?.sequences?.filter(s => s.id !== newLink.sequenceId).map(sequence => (
                        <option key={sequence.id} value={sequence.id}>{sequence.title}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="link-title">Link Title *</Label>
                <Input
                  id="link-title"
                  placeholder="e.g., Next: Advanced Topics"
                  value={newLink.title}
                  onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="link-type">Link Type *</Label>
                <select
                  id="link-type"
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  value={newLink.type}
                  onChange={(e) => setNewLink({ ...newLink, type: e.target.value as "next" | "prerequisite" | "related" })}
                >
                  <option value="next">Next</option>
                  <option value="prerequisite">Prerequisite</option>
                  <option value="related">Related</option>
                </select>
              </div>

              <Button onClick={handleAddLink} className="w-full bg-gradient-accent hover:opacity-90">
                <Link2 className="w-4 h-4 mr-2" />
                Add Link
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Existing Courses */}
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold">Manage Existing Courses</h2>
          
          {courses.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground">No courses created yet. Add your first course above!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {courses.map((course) => (
                <Card key={course.id} className="overflow-hidden">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <CardTitle className="flex items-center gap-2">
                          {course.title}
                          <Badge variant="secondary">{course.subject}</Badge>
                        </CardTitle>
                        <div className="flex gap-4 text-sm text-muted-foreground">
                          <span>{course.sequences?.length || 0} sequences</span>
                          <span>{course.sequences?.reduce((acc, seq) => acc + seq.videos.length, 0) || 0} total videos</span>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteCourse(course.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  
                  {course.sequences && course.sequences.length > 0 && (
                    <CardContent className="space-y-6">
                      {course.sequences.map((sequence) => (
                        <div key={sequence.id} className="border rounded-lg p-4 space-y-4">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <h4 className="font-semibold flex items-center gap-2">
                                {sequence.title}
                                <Badge variant="outline">{sequence.videos.length} videos</Badge>
                              </h4>
                              {sequence.description && (
                                <p className="text-sm text-muted-foreground">{sequence.description}</p>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteSequence(course.id, sequence.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>

                          {/* Sequence Links */}
                          {sequence.links && sequence.links.length > 0 && (
                            <div className="space-y-2">
                              <h5 className="text-sm font-medium flex items-center gap-2">
                                <Link2 className="w-4 h-4" />
                                Links
                              </h5>
                              <div className="flex flex-wrap gap-2">
                                {sequence.links.map((link) => (
                                  <Badge key={link.id} variant="secondary" className="text-xs">
                                    {link.title} ({link.type})
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Videos */}
                          {sequence.videos.length > 0 && (
                            <div className="space-y-2">
                              <h5 className="text-sm font-medium">Videos:</h5>
                              <div className="space-y-2">
                                {sequence.videos.map((video) => (
                                  <div key={video.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                                    <div className="space-y-1">
                                      <p className="font-medium text-sm">{video.title}</p>
                                      <div className="flex gap-3 text-xs text-muted-foreground">
                                        <span>ID: {video.youtubeId}</span>
                                        {video.duration && <span>{video.duration}</span>}
                                      </div>
                                    </div>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleDeleteVideo(course.id, sequence.id, video.id)}
                                      className="text-destructive hover:text-destructive"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
