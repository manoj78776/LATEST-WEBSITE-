import { useEffect } from "react";
import { StudyDashboard } from "@/components/StudyDashboard";
import { mathCourse } from "@/data/mathCourse";

const Math = () => {
  // Add the mathematics course to localStorage when the component mounts
  useEffect(() => {
    const savedCourses = localStorage.getItem('studyCourses');
    let courses = [];
    
    if (savedCourses) {
      courses = JSON.parse(savedCourses);
    }
    
    // Check if math course already exists
    const mathCourseExists = courses.some((course: any) => course.id === mathCourse.id);
    
    if (!mathCourseExists) {
      // Add the mathematics course
      courses.push(mathCourse);
      localStorage.setItem('studyCourses', JSON.stringify(courses));
      
      // Refresh the page to show the new course
      window.location.reload();
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-hero bg-clip-text text-transparent mb-4">
            NDA Shaurya 1.0 2026
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-2">
            Mathematics Course
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive mathematics preparation for NDA examination. Master all essential topics with structured video lectures.
          </p>
        </div>
        <StudyDashboard />
      </div>
    </div>
  );
};

export default Math;