import { useState, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { VideoPlayer } from "@/components/VideoPlayer";
import { Course, Video, Sequence } from "@/types/course";
import { mathCourse } from "@/data/mathCourse";

export const VideoPlayerPage = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sequenceId = searchParams.get('sequence');
  const videoId = searchParams.get('video');

  const [course, setCourse] = useState<Course | null>(null);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [selectedSequence, setSelectedSequence] = useState<Sequence | null>(null);

  useEffect(() => {
    // For now, we'll use the math course as default
    // Later this can be expanded to load different courses
    const loadedCourse = mathCourse;
    setCourse(loadedCourse);

    if (sequenceId) {
      const sequence = loadedCourse.sequences?.find(s => s.id === sequenceId);
      if (sequence) {
        setSelectedSequence(sequence);
        
        // Find the video to play
        let targetVideo: Video | null = null;
        if (videoId) {
          targetVideo = sequence.videos.find(v => v.id === videoId) || null;
        } else {
          // Find first incomplete video or first video
          targetVideo = sequence.videos.find(v => !v.completed) || sequence.videos[0];
        }
        
        if (targetVideo) {
          setCurrentVideo(targetVideo);
        }
      }
    } else if (videoId) {
      // Find video across all sequences
      const allVideos = loadedCourse.sequences?.flatMap(s => s.videos) || [];
      const targetVideo = allVideos.find(v => v.id === videoId);
      if (targetVideo) {
        setCurrentVideo(targetVideo);
      }
    }
  }, [courseId, sequenceId, videoId]);

  const handleBack = () => {
    navigate(-1);
  };

  const handleVideoComplete = (videoId: string) => {
    if (!course) return;

    // Update video completion status
    const updatedCourse = { ...course };
    updatedCourse.sequences?.forEach(sequence => {
      sequence.videos.forEach(video => {
        if (video.id === videoId) {
          video.completed = !video.completed;
        }
      });
    });

    setCourse(updatedCourse);
    
    // Update current video state
    if (currentVideo && currentVideo.id === videoId) {
      setCurrentVideo({ ...currentVideo, completed: !currentVideo.completed });
    }
  };

  const handleVideoChange = (video: Video) => {
    setCurrentVideo(video);
    
    // Update URL to reflect current video
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('video', video.id);
    navigate(`?${newSearchParams.toString()}`, { replace: true });
  };

  if (!course || !currentVideo) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Loading...</h2>
          <p className="text-muted-foreground">Please wait while we load your content.</p>
        </div>
      </div>
    );
  }

  return (
    <VideoPlayer
      course={course}
      currentVideo={currentVideo}
      selectedSequence={selectedSequence}
      onBack={handleBack}
      onVideoComplete={handleVideoComplete}
      onVideoChange={handleVideoChange}
    />
  );
};