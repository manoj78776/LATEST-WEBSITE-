// Shared interfaces for the course structure
export interface Video {
  id: string;
  title: string;
  youtubeId: string;
  duration?: string;
  completed?: boolean;
}

export interface Sequence {
  id: string;
  title: string;
  videos: Video[];
  description?: string;
  links?: SequenceLink[];
}

export interface SequenceLink {
  id: string;
  title: string;
  targetSequenceId: string;
  type: 'next' | 'prerequisite' | 'related';
}

export interface Course {
  id: string;
  title: string;
  subject: string;
  sequences: Sequence[];
  // Legacy support for old video structure
  videos?: Video[];
}